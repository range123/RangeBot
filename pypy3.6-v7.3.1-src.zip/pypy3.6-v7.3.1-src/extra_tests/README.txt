The tests in this directory are a complement to lib-python/3/test/.

They are meant to run on top of a compiled pypy3 or CPython3.5 in an
environment containing at least pytest and hypothesis, using a command like
'pytest extra_tests/'.
